import os
import uuid
import shutil
import urllib.request
import urllib.error
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from app.fashn_service import run_fashn, detect_category
from app.chat_service import chat as vastra_chat

load_dotenv()

app = FastAPI(title="VastraX Virtual Try-On API")
from mangum import Mangum
handler = Mangum(app)

# ── CORS ──
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Directories ──
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
# AWS Lambda execution environments are read-only except for /tmp
if "AWS_LAMBDA_FUNCTION_NAME" in os.environ:
    UPLOAD_DIR  = os.getenv("UPLOAD_DIR",  "/tmp/user_uploads")
    RESULTS_DIR = os.getenv("RESULTS_DIR", "/tmp/results")
else:
    UPLOAD_DIR  = os.getenv("UPLOAD_DIR",  os.path.join(BASE_DIR, "..", "user_uploads"))
    RESULTS_DIR = os.getenv("RESULTS_DIR", os.path.join(BASE_DIR, "..", "results"))
DIST_DIR    = os.getenv("DIST_DIR",    os.path.normpath(os.path.join(BASE_DIR, "..", "..", "dist")))

os.makedirs(UPLOAD_DIR,  exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)



def resolve_garment(garment_path: str):
    """
    Accepts a relative path (/catalog/...) or any http/https URL.
    Relative paths are resolved against the built frontend dist folder.
    Remote URLs are downloaded to a temp file. Returns (local_path, is_temp).
    """
    if garment_path.startswith("http://") or garment_path.startswith("https://"):
        ext = os.path.splitext(garment_path.split("?")[0])[1] or ".jpg"
        tmp_path = os.path.join(UPLOAD_DIR, f"garment_{uuid.uuid4().hex[:8]}{ext}")
        try:
            urllib.request.urlretrieve(garment_path, tmp_path)
        except urllib.error.URLError as e:
            raise HTTPException(
                status_code=400,
                detail=f"Could not download garment image: {e.reason}"
            )
        return tmp_path, True

    # Relative path — resolve against the built frontend dist
    local_path = os.path.normpath(os.path.join(DIST_DIR, garment_path.lstrip("/")))
    return local_path, False


# ── Health ──

@app.get("/api")
async def root():
    return {"service": "VastraX Virtual Try-On API", "model": "FASHN VTON 1.5", "status": "running"}

@app.get("/api/health")
async def health():
    return {"status": "ok"}


# ── Try-On ──

@app.post("/api/try-on")
async def try_on(
    person_image: UploadFile = File(...),
    garment_path: str        = Form(...),
    garment_type: str        = Form(default=None)
):
    person_path    = None
    garment_local  = None
    garment_is_tmp = False

    try:
        ext = os.path.splitext(person_image.filename)[1] or ".jpg"
        person_path = os.path.join(UPLOAD_DIR, f"person_{uuid.uuid4().hex[:8]}{ext}")
        with open(person_path, "wb") as f:
            shutil.copyfileobj(person_image.file, f)

        garment_local, garment_is_tmp = resolve_garment(garment_path)

        if not os.path.exists(garment_local):
            raise HTTPException(status_code=404, detail=f"Garment image not found: {garment_path}")

        category = garment_type if garment_type in [
            "tops", "bottoms", "one-pieces"
        ] else detect_category(garment_path)

        result_path = run_fashn(
            person_image_path  = person_path,
            garment_image_path = garment_local,
            garment_type       = category,
            results_dir        = RESULTS_DIR
        )

        return {
            "status":        "success",
            "result_url":    f"/results/{os.path.basename(result_path)}",
            "category_used": category,
            "model":         "FASHN VTON 1.5"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        if person_path and os.path.exists(person_path):
            os.remove(person_path)
        if garment_is_tmp and garment_local and os.path.exists(garment_local):
            os.remove(garment_local)


# ── Vastra AI Style Chat ──

from pydantic import BaseModel
from typing import List

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    profile: dict = {}

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    messages = [{"role": m.role, "content": m.content} for m in req.messages]
    reply = vastra_chat(messages, req.profile)
    return {"message": reply}


# ── Try-On Combo (2-pass: top first, then bottom) ──

@app.post("/api/try-on-combo")
async def try_on_combo(
    person_image: UploadFile = File(...),
    top_path: str            = Form(...),
    bottom_path: str         = Form(...),
):
    """
    Two-pass virtual try-on for a complete outfit.
    Pass 1: drape the top onto the person.
    Pass 2: drape the bottom onto the pass-1 result.
    Useful when the customer is wearing a kurti/long top that covers the legs.
    """
    person_path     = None
    top_local       = None
    bottom_local    = None
    top_is_tmp      = False
    bottom_is_tmp   = False
    intermediate    = None

    try:
        # Save the uploaded portrait
        ext = os.path.splitext(person_image.filename)[1] or ".jpg"
        person_path = os.path.join(UPLOAD_DIR, f"person_{uuid.uuid4().hex[:8]}{ext}")
        with open(person_path, "wb") as f:
            shutil.copyfileobj(person_image.file, f)

        top_local,    top_is_tmp    = resolve_garment(top_path)
        bottom_local, bottom_is_tmp = resolve_garment(bottom_path)

        if not os.path.exists(top_local):
            raise HTTPException(status_code=404, detail=f"Top garment not found: {top_path}")
        if not os.path.exists(bottom_local):
            raise HTTPException(status_code=404, detail=f"Bottom garment not found: {bottom_path}")

        # Pass 1 — replace the top; save intermediate into UPLOAD_DIR (temp)
        intermediate = run_fashn(
            person_image_path  = person_path,
            garment_image_path = top_local,
            garment_type       = "tops",
            results_dir        = UPLOAD_DIR,
        )

        # Pass 2 — drape the pants on the pass-1 result
        result_path = run_fashn(
            person_image_path  = intermediate,
            garment_image_path = bottom_local,
            garment_type       = "bottoms",
            results_dir        = RESULTS_DIR,
        )

        return {
            "status":        "success",
            "result_url":    f"/results/{os.path.basename(result_path)}",
            "category_used": "combo (tops + bottoms)",
            "model":         "FASHN VTON 1.5",
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    finally:
        for p in [person_path, intermediate]:
            if p and os.path.exists(p):
                try: os.remove(p)
                except: pass
        if top_is_tmp and top_local and os.path.exists(top_local):
            try: os.remove(top_local)
            except: pass
        if bottom_is_tmp and bottom_local and os.path.exists(bottom_local):
            try: os.remove(bottom_local)
            except: pass


# ── Static: result images ──
app.mount("/results", StaticFiles(directory=RESULTS_DIR), name="results")

# ── Static: Vite compiled assets (hashed JS/CSS) ──
_assets_dir = os.path.join(DIST_DIR, "assets")
if os.path.isdir(_assets_dir):
    app.mount("/assets", StaticFiles(directory=_assets_dir), name="assets")

# ── Static: product catalog images ──
_catalog_dir = os.path.join(DIST_DIR, "catalog")
if os.path.isdir(_catalog_dir):
    app.mount("/catalog", StaticFiles(directory=_catalog_dir), name="catalog")


# ── SPA catch-all: serve real files from dist/ or fall back to index.html ──
@app.get("/{full_path:path}")
async def serve_spa(full_path: str):
    index_html = os.path.join(DIST_DIR, "index.html")

    if not os.path.isfile(index_html):
        return {"error": "Frontend not built. Run: npm run build"}

    # Serve real static files that exist at the path (logo.png, favicon, etc.)
    if full_path:
        candidate = os.path.normpath(os.path.join(DIST_DIR, full_path))
        # Guard against path traversal
        if candidate.startswith(DIST_DIR) and os.path.isfile(candidate):
            return FileResponse(candidate)

    # SPA fallback — React Router handles the route client-side
    return FileResponse(index_html)

import subprocess
import shutil
import uuid
import os

# ── FASHN VTON 1.5 Paths (configurable via .env) ──
FASHN_VENV    = os.getenv("FASHN_VENV",    "/home/pkr/fashn-tryon/venv/bin/python")
FASHN_SCRIPT  = os.getenv("FASHN_SCRIPT",  "/home/pkr/fashn-tryon/fashn-vton-1.5/examples/basic_inference.py")
FASHN_WEIGHTS = os.getenv("FASHN_WEIGHTS", "/home/pkr/fashn-tryon/fashn-vton-1.5/weights")
FASHN_OUTPUT  = os.getenv("FASHN_OUTPUT",  "/home/pkr/fashn-tryon/fashn-vton-1.5/results/output_00.png")
FASHN_RESULTS = os.getenv("FASHN_RESULTS", "/home/pkr/fashn-tryon/fashn-vton-1.5/results")


def detect_category(garment_path: str) -> str:
    """
    Auto-detect FASHN category from garment filename or URL.

    Supported categories:
      one-pieces : frocks, dresses, gowns, jumpsuits, body-con
      bottoms    : pants, jeans, skirts, leggings
      tops       : everything else (shirts, kurtas, blouses, cardigans)
    """
    path = garment_path.lower()

    if any(w in path for w in [
        "frock", "dress", "gown", "lehenga",
        "bodycon", "body_con", "body-con",
        "floral", "textured", "midi", "maxi",
        "jumpsuit", "overall"
    ]):
        return "one-pieces"

    elif any(w in path for w in [
        "pant", "jean", "denim", "skirt",
        "trouser", "flared", "beige", "shorts",
        "palazzo", "culottes", "legging", "bottom"
    ]):
        return "bottoms"

    else:
        return "tops"


def run_fashn(
    person_image_path: str,
    garment_image_path: str,
    garment_type: str = None,
    results_dir: str = None
) -> str:
    """
    Run FASHN VTON 1.5 inference on the GPU machine.
    Returns the local path to the result image.
    """
    category = garment_type if garment_type in [
        "tops", "bottoms", "one-pieces"
    ] else detect_category(garment_image_path)

    cmd = [
        FASHN_VENV,
        FASHN_SCRIPT,
        "--weights-dir", FASHN_WEIGHTS,
        "--person-image", person_image_path,
        "--garment-image", garment_image_path,
        "--category", category,
        "--output-dir", FASHN_RESULTS
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=120
    )

    if result.returncode != 0:
        raise Exception(f"FASHN inference error: {result.stderr[-800:]}")

    if not os.path.exists(FASHN_OUTPUT):
        raise Exception("FASHN did not produce an output image")

    if results_dir:
        os.makedirs(results_dir, exist_ok=True)
        result_filename = f"result_{uuid.uuid4().hex[:8]}.png"
        result_dest = os.path.join(results_dir, result_filename)
        shutil.copy2(FASHN_OUTPUT, result_dest)
        return result_dest

    return FASHN_OUTPUT

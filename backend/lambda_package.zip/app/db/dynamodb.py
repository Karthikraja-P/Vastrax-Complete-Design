import os
import boto3

def get_dynamodb():
    region = os.getenv("AWS_DEFAULT_REGION", "ap-south-1")
    return boto3.resource("dynamodb", region_name=region)
